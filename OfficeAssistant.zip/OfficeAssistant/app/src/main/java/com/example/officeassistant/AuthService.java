package com.example.officeassistant;

import android.util.Log;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AuthService {
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    public FirebaseUser signIn(String email,String password){
        try{
            AuthResult result=auth.signInWithEmailAndPassword(email,password).getResult();
            if (result != null) {
                return result.getUser();
            }
            else return null;
        }
        catch (Exception e){
            Log.d(e.getMessage(),"Error");
            return null;
        }
    }
    public void signOut(){
        auth.signOut();
    }

}
